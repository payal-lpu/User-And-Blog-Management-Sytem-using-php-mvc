<?php
	include_once ('class/DBController.php');
	include_once ('class/Pagination.php');
	$db_handle=new DBController();
?>
<html>
<head>
    <style>
	body, html {
				height: 100%;
				margin: 0;
			}
        #logout
        {
            float:right;
			padding-right:30px;
			padding-top:10px;
        }

        #container
            {
                padding-left:650px;
                padding-top:100px;
				background:linear-gradient(white,#ff69b4); height: 100%; 

				/* Center and scale the image nicely */
				background-position: center;
				background-repeat: no-repeat;
				background-size: cover;
            }
			
			a
			{
				transition:width 1s;
			}
			a:hover
			{
				font-size:20px;
			}
		
    </style>
</head>

    <a href="index.php?action=logout" id="logout">Logout</a>
	<a href="index.php?action=createBlog">Create New Blog</a><br>
	<a href="index.php?action=LandingAfterLogin">Go Back!</a>
	<h1 align="center">Blogs!!</h1>
    <body>
        <div id="container">
            <table cellpadding="20" cellspacing="1" border="1">
<thead>
    <tr>
        <td><strong>Blog Title</strong></td>
        <td><strong>Short Description<strong></td>
        <td><strong>Published Date<strong></td>
        <td><strong>Author<strong></td>
		<td><strong>Image<strong></td>
		<td><strong>Action<strong></td>
    </tr>
</thead>
    <?php
		$pag=new Pagination();
		$results_per_page=2;
		$this_page_first_result=$pag->paginate($results_per_page);
		$result=$pag->select($this_page_first_result,$results_per_page);
        if(!empty($result))
        {
            foreach($result as $rows)
            {	
    ?>
    <tr>
        <td><?php echo $rows['title'];?></td>
        <td><?php echo $rows['shortDesc']; ?></td>
        <td><?php echo $rows['publishedDate']; ?></td>
        <td><?php echo $rows['author']; ?></td>
		<td><img src="images/<?php echo $rows['image'];?>" height="100px" width="100px"></td>
		<td>
			<a href="index.php?action=delete&blogId=<?php echo $rows['blogID'];?>" onclick="return confirm('Are you sure you want to delete')">Delete</a>|
			<a href="index.php?action=edit&blogId=<?php echo $rows['blogID'];?>">Edit</a>
		</td>
		<br/>
	</tr>
    <?php
              }  
        }

        else
        {
            
            echo "No Blogs Exist";
			?>
			<a href="index.php?action=createBlog">Create Blog</a>
			<?php
        }
       ?>
   
	

</table>
	<?php
			$number_of_pages=$pag->noOfPages($results_per_page);
			for ($page=1;$page<=$number_of_pages;$page++)
			{
				echo '<a href="index.php?action=pagination&page=' . $page . '" id="pagination">' . $page . '</a> ';
			}
		?>
		<br>
		
        </div>
		
    </body>
</html>
