<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8">
		<title>Registration Form</title>
		
		<style>
		body, html {
				height: 100%;
				margin: 0;
			}
			#container
			{
				padding-left:750px;
				padding-top:40px;
				background:linear-gradient(white,#ff69b4); height: 100%; 

				/* Center and scale the image nicely */
				background-position: center;
				background-repeat: no-repeat;
				background-size: cover;
			}
	
			.textBox
			{
				border-radius:8px;
			}
			
			a
	{
		transition:width 1s;
	}
	a:hover
	{
		font-size:20px;
	}
		</style>
		
		<script type="text/javascript">
			
			function validate()
			{
				var first=document.f1.fname.value;
				var last=document.f1.lname.value;
				var letters = /^[A-Za-z]+$/;
				
				if(first.match(letters) && last.match(letters))
				{
					return true;
				}
				
				else
				{
					alert("Firstname And Lastname should only be characters ");
					return false;
				}
			}
		</script>
	</head>

<body>
	<h1 align="center">Registration Form</h1>
	<div id="container">
		<form name="f1" action="index.php?action=registerIntoDatabase" method="post" onsubmit="return validate()">
		<table cellspacing=10>
			<tr><td><label><strong>Firstname : </td><td></strong></label><input type="text" name="fname" class="textBox" required></td></tr>
			<tr><td><label><strong>LastName : </td><td></strong></label><input type="text" name="lname" class="textBox" id="lname" required></td></tr>
			<tr><td><label><strong>Email : </td><td></strong></label><input type="email" name="email" size="30" class="textBox" required></td></tr>
			<tr><td><label><strong>DOB : </td><td></strong></label><input type="date" name="dob" class="textBox" required></td></tr>
			<tr><td><label><strong>Phone: </td><td></strong></label><input type="tel" name="phone" pattern="[0-9]{10}" class="textBox" required></td></tr>
			<tr><td><label><strong>Username : </td><td></strong></label><input type="text" name="username" class="textBox" required></td></tr>
			<tr><td><label><strong>Password : </td><td></strong></label><input type="password" minlength="6" name="password" class="textBox" required></td></tr>
			<tr><td colspan=2><input type="checkbox" name="terms" required>Above Enter data is correct</td></tr>
			<tr><td align="center" colspan=2><input type="submit" value="Register"> <input type="reset" value="Reset"></td></tr>
	</form>
	</table>
	</div> 
</body>
</html>