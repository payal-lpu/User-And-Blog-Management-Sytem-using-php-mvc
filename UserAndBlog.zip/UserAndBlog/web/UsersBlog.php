<?php
	include_once ('class/DBController.php');
	include_once ('class/Pagination.php');
	$db_handle=new DBController();
?>
<html>
<head>
    <style>
	body, html {
				height: 100%;
				margin: 0;
			}
        #logout
        {
            float:right;
			padding-right:30px;
			padding-top:10px;
        }

        #container
            {
                padding-left:500px;
                padding-top:200px;
				background:linear-gradient(white,#ff69b4); height: 100%; 

				/* Center and scale the image nicely */
				background-position: center;
				background-repeat: no-repeat;
				background-size: cover;
            }
			
			a
	{
		transition:width 1s;
	}
	a:hover
	{
		font-size:20px;
	}
	
    </style>
</head>
    <body>
    <a href="index.php?action=logout" id="logout">Logout</a><br>
	<a href="index.php?action=showBlogs">Go Back!</a>
        <div id="container">
            <table cellpadding="20" cellspacing="1" border="1">
<thead>
    <tr>
        <th>Blog Title  </th>
        <th>Short Description </th>
        <th>Published Date </th>
        <th>Author</th>
		<th>Image</th>
        <th>Action</th>
    <tr>

    <?php
		$pag=new Pagination();
		$results_per_page=2;
		$this_page_first_result=$pag->paginateAdmin($results_per_page);
		$result=$pag->selectAdmin($this_page_first_result,$results_per_page);
		
        if(!empty($result))
        {
            foreach($result as $rows)
            {
    ?>

    <tr>
        <td><?php echo $rows['title'];?></td>
        <td><?php echo $rows['shortDesc']; ?></td>
        <td><?php echo $rows['publishedDate']; ?></td>
        <td><?php echo $rows['author']; ?></td>
		<td><img src="images/<?php echo $rows['image'];?>" height="100px" width="100px"></td>
        <td><a href="index.php?action=deleteForAdmin&blogID=<?php echo $rows['blogID'];?>" onclick="return confirm('Are you sure you want to delete')">Delete</a> |
		<a href="index.php?action=editForAdmin&blogID=<?php echo $rows['blogID'];?>">Edit</a></td>
    </tr>
    <?php
    }
        }
		else
		{
			
    ?>
		<a href="index.php?action=showBlogs">No blogs exist Return</a>
		<?php
		}
		?>
</thead>
</table>
<?php
			$number_of_pages=$pag->noOfPagesAdmin($results_per_page);
			for ($page=1;$page<=$number_of_pages;$page++)
			{
				echo '<a href="index.php?action=paginationByAdmin&page=' . $page . '" id="pagination">' . $page . '</a> ';
			}
		?>
        </div>
    </body>
</html>