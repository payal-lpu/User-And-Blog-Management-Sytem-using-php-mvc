<style>
body, html {
				height: 100%;
				margin: 0;
			}
	#logout
	{
		float:right;
		padding-right:30px;
		padding-top:10px;
	}
	
	body{
		background:linear-gradient(white,#ff69b4);
	}
	
	a
	{
		transition:width 1s;
	}
	a:hover
	{
		font-size:20px;
	}
</style>
<body>
<a href="index.php?action=logout" id="logout">Logout</a>
<a href="index.php?action=ListUser">List of User</a></br></br>
<a href="index.php?action=UsersBlog">Show users blog</a>
</body>