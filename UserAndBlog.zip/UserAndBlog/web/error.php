<?php
	echo "Error : ".mysqli_error();
?>
<div>
	<a href="index.php?action=choose">Go back to HomePage</a>
</div>