<!DOCTYPE html>
<html>
	<head>
		<title>Login Form</title>
		<style>
		body, html {
				height: 100%;
				margin: 0;
			}
			#container
			{
				padding-left:750px;
				padding-top:100px;
				background:linear-gradient(white,#ff69b4); height: 100%; 

				/* Center and scale the image nicely */
				background-position: center;
				background-repeat: no-repeat;
				background-size: cover;
			}
			
			.textBox
			{
				border-radius:8px;
			}
			
			#loginButton
			{
				margin-left:150px;
				padding:5px;
				background-color:green;
				width:50px;
			}
			
			/*#body
			{
				background:linear-gradient(white,#FF69B4);
			}*/
		</style>
	</head>
	
	<body>
		<h1 align="center">Login Form!!</h1>
		<div id="container">
			<form action="index.php?action=checkUser" method="post"name="f1">
			<label><strong>Username : </strong></label><input type="text" name="username" class="textBox" required><br><br>
			<label><strong>Password : &nbsp;</strong></label><input type="password" name="password" class="textBox" required><br><br>
			<input type="submit" value="login" id="loginButton">
		</form>
		</div>
	</body>
</html>