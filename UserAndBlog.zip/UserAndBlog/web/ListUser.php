<!DOCTYPE html>
<html>
	<head>
		<title>List of User</title>
		<meta charset="utf-8">
		
		<style>
			body, html
			{
				height: 100%;
				margin: 0;
			}
			
			#logout
			{
				float:right;
				padding-right:30px;
				padding-top:10px;
			}

			#container
            {
                padding-left:700px;
                padding-top:60px;
				background:linear-gradient(white,#ff69b4); height: 100%; 

				/* Center and scale the image nicely */
				background-position: center;
				background-repeat: no-repeat;
				background-size: cover;
            }
			
			a
			{
				transition:width 1s;
			}
			
			a:hover
			{
				font-size:20px;
			}
		</style>
	</head>
	
	<body>
		<a href="index.php?action=logout" id="logout">Logout</a>
		<h1 align="center">User's List</h1><br>
		<a href="index.php?action=showBlogs">Go Back</a>
		<div id="container">
			<table cellpadding="40" cellspacing="1" border="1">
				<tr>
					<td><strong>UserId</strong></td>
					<td><strong>User</strong></td>
					<td><strong>Action</strong></td>
				<tr>
				
				<?php
					if(!empty($result))
					{
						foreach($result as $rows)
						{
				?>

				<tr>
					<td><?php echo $rows['id'];?></td>
					<td><?php echo $rows['firstname']." " .$rows['lastname'];?></td>
					<td><a href="index.php?action=deleteUser&id=<?php echo $rows['id'];?>" onclick="return confirm('Are you sure you want to delete')">Delete</a>
				</tr>
				
				<?php
						}
					}
					
					else
					{
			
				?>
				
				<a href="index.php?action=showBlogs">No user exist Return</a>
				<?php
					}
				?>
			</table>
		</div>
	</body>
</html>