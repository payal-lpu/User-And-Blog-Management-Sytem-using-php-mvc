<style>
body, html {
				height: 100%;
				margin: 0;
			}
	#container
	{
		padding-left:750px;
		padding-top:100px;
		background:linear-gradient(white,#ff69b4); height: 100%; 

				/* Center and scale the image nicely */
				background-position: center;
				background-repeat: no-repeat;
				background-size: cover;
	}
	
	.textBox
	{
		border-radius:8px;
	}
	
	#button
	{
		margin-left:150px;
		padding:5px;
		background-color:green;
		width:80px;
	}
	
	#logout
	{
		float:right;
		padding-right:30px;
		padding-top:10px;
	}
	
	a
	{
		transition:width 1s;
	}
	a:hover
	{
		font-size:20px;
	}

	
</style>
<body>
<a href="index.php?action=logout" id="logout">Logout</a><br>
<a href="index.php?action=LandingAfterLogin">Go BAck!</a>
<h1 align="center">User Blog Creation </h1>

<div id="container">
	
	<form action="index.php?action=SaveBlogDetails" method="post" enctype="multipart/form-data">
	
		<label><strong>Blog Title : </strong></label><input type="text" name="title" class="textBox" required><br><br>
		<label><strong>Short Desc : </strong></label><input type="text" name="shortDesc" class="textBox" required><br><br>
		<label><strong>Published Date : </strong></label><input type="date" name="publishedDate" class="textBox" required><br><br>
		<label><strong>Author : </strong></label><input type="text" name="author" class="textBox" pattern="[A-Za-z]+" required><br><br>
		<label><strong>Upload Image:</strong></label><input type="file" name="image"><br><br>
		<input type="submit" value="Add Data" id="button">

	</form>
</div> 
</body>