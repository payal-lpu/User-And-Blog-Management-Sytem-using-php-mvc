<style>
	body, html {
				height: 100%;
				margin: 0;
			}
	body
	{
		background:linear-gradient(white,#ff69b4);
	}
	
	a
	{
		transition:width 1s;
	}
	a:hover
	{
		font-size:20px;
	}
</style>
<body>
    <h1>Registered Successfully</h1>

    <a href="index.php?action=''">Go to HOme page and Login</a>
</body>