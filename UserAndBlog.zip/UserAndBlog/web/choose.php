<style>
	#container
	{
		padding-left:750px;
		padding-top:200px;
	}
	
	#body
	{
		background:linear-gradient(white,#ff69b4);
	}
	
	.link
	{
		transition:width 1s;
	}
	.link:hover
	{
		font-size:20px;
	}
</style>
<body id="body">
    <div id="container">
		<table border="1" cellpadding="40px">
		<tr>
			<td><a href="index.php?action=register" class="link"><strong>Register</strong></a></td>
			<td><a href="index.php?action=login" class="link"><strong>Login</strong></a></td>
		</tr>
	</table>
	</div>
</body>