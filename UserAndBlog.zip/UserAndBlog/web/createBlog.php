<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <style>
			body, html {
				height: 100%;
				margin: 0;
			}
            #logout
            {
                float:right;
				padding-right:30px;
				padding-top:10px;
            }

            #container
            {
                padding-left:750px;
                padding-top:200px;
				background:linear-gradient(white,#ff69b4); height: 100%; 

				/* Center and scale the image nicely */
				background-position: center;
				background-repeat: no-repeat;
				background-size: cover;
            }
			
			.link
			{
				transition:width 1s;
			}
			.link:hover
			{
				font-size:20px;
			}
			
        </style>
    </head>
    
    <body id="body">
        <a href="index.php?action=logout" id="logout">Logout</a>
        <div id="container">
            <table border="1" cellpadding="40px">
            <tr>
                <td><a href="index.php?action=BlogForm" class="link"><strong>Create Blog Link</strong></a><br><br></td>
                <td><a href="index.php?action=showBlog" class="link"><strong>Blogs</strong></a></td>
            </tr>
			</table>
        </div>
	</body>
</html>



