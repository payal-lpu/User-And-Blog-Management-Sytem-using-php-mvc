<?php
require_once ("class/DBController.php");

$db_handle = new DBController();

$action = "";
if (! empty($_GET["action"]))
{
    $action = $_GET["action"];
	$withoutlogin= array("register", "login");
	if(in_array($action, $withoutlogin) )
	{
		if(isset($_SESSION['user_id']) && $_SESSION['user_id'] != '')
		{
			header("Location: http://localhost:80/UserAndBlog/index.php?action=showBlog");
		}
	}
}
/*else{
	header("Location: http://localhost:80/UserAndBlog/");
}*/
switch ($action) {

    case "register":
        require_once "web/registerForm.php";
        break;

    case "login":
        require_once "web/loginForm.php";
        break;

    case "registerIntoDatabase":
		if(isset($_POST['fname']))
		{
			$fname=$_POST['fname'];
			$fname=filter_var($fname, FILTER_SANITIZE_STRING);
			//$fname=mysqli_real_escape_string($db_handle,filter_var($fname, FILTER_SANITIZE_STRING));
		}
		
		if(isset($_POST['lname']))
		{
			$lname=$_POST['lname'];
			$lname=filter_var($lname, FILTER_SANITIZE_STRING);
		}
		
		if(isset($_POST['email']))
		{
			$email=$_POST['email'];
			$email=filter_var($email, FILTER_SANITIZE_STRING);
		}
		
		if(isset($_POST['dob']))
		{
			$dob=$_POST['dob'];
			$dob=filter_var($dob, FILTER_SANITIZE_STRING);
		}
		
		if(isset($_POST['phone']))
		{
			$phone=$_POST['phone'];
			$phone=filter_var($phone, FILTER_SANITIZE_STRING);
		}
		
		if(isset($_POST['username']))
		{
			$username=$_POST['username'];
			$username=filter_var($username, FILTER_SANITIZE_STRING);
		}
		
		if(isset($_POST['password']))
		{
			$password=$_POST['password'];
			$password=filter_var($password, FILTER_SANITIZE_STRING);
			$encodedPassword=md5($password);
		}
		
		
		$sql="SELECT username FROM user WHERE username='$username'";
		$count=$db_handle->countRecord($sql);
		if($count)
		{
			echo "Username already exist";
		}
		
		if($username=='adminLogin')
		{
			$user_type="admin";  
		}
		
		else
		{
			$user_type="user";
		}
		
        $sql="INSERT INTO user values('','$fname','$lname','$email','$dob','$phone','$username','$encodedPassword','$user_type')";
        $result=$db_handle->insert($sql);

        if($result)
        {
            include 'web/registered.php';
        }

        else
        {
            echo "Failed to register Into database: " . mysqli_error($db_handle);
            include 'web/error.php';
        }
        break;

    case "checkUser":
		$user;
		$password;
		
		if(isset($_POST['username']))
		{
			$user=$_POST['username'];
			$user=filter_var($user, FILTER_SANITIZE_STRING);
		}
        
		if(isset($_POST['password']))
		{
			$password=$_POST['password'];
			$password=filter_var($password, FILTER_SANITIZE_STRING);
			
		}
        $encodedPassword=md5($password);
		$sql="SELECT ID,user_type from user where username='$user' and password='$encodedPassword'";
        $result=$db_handle->fetchRecord($sql,$user);
		 if(!empty($result))
		{
			foreach($result as $rows)
			{
				$_SESSION['user_id']=$rows["ID"];
			}
			if($rows['user_type']=='admin')
			require_once 'web/showBlogs.php';
			else
			require_once 'web/createBlog.php';
		}

		else
		{
			echo "User doesn't exist: " . mysqli_error($db_handle);
			require_once "web/error.php";
		}
        break;

    case "BlogForm":
        require_once "web/BlogForm.php";
        break;
		
	case "LandingAfterLogin":
		require_once "web/createBlog.php";
		break;

    case "SaveBlogDetails":
		$user_id=$_SESSION['user_id'];
		if(isset($_POST['title']))
		{
			$title=$_POST['title'];
			$title=filter_var($title, FILTER_SANITIZE_STRING);
		}
		
		if(isset($_POST['shortDesc']))
		{
			$shortDesc=$_POST['shortDesc'];
			$shortDesc=filter_var($shortDesc, FILTER_SANITIZE_STRING);
		}
		
		if(isset($_POST['publishedDate']))
		{
			$publishedDate=$_POST['publishedDate'];
			$publishedDate=filter_var($publishedDate, FILTER_SANITIZE_STRING);
		}
		
		if(isset($_POST['author']))
		{
			$author=$_POST['author'];
			$author=filter_var($author, FILTER_SANITIZE_STRING);
		}
		
		$image = $_FILES['image']['name'];
		$target = "images/".basename($image);
		$temp=$_FILES['image']['tmp_name'];
        $sql="INSERT INTO blog values('','$title','$shortDesc','$publishedDate','$author','$user_id','$image')";
        $result=$db_handle->insertBlogDetails($sql,$temp,$target);

        if($result)
        {
            include 'web/createBlog.php';
        }

        else
        {
            echo "Error in saving the Blog Details  " . mysqli_error($db_handle);
            include 'web/error.php';
        }
        break;

    case "showBlog":
        $user=$_SESSION['user_id'];
        //$sql="SELECT blogId,title,shortDesc,publishedDate,author FROM blog WHERE id='$_SESSION[user_id]'";
        //$result=$db_handle->fetchRecord($sql);
        require_once 'web/Blogs.php';
        break;
		
	case "edit":
		$_SESSION['blogId']=$_GET['blogId'];
		$sql="SELECT * from blog where blogID='$_SESSION[blogId]'";
		$result=$db_handle->fetchRecord($sql);
		require_once 'web/BlogFormEdit.php';
        break;
		
	case "editForAdmin":
		$_SESSION['blogID']=$_GET['blogID'];
		$sql="SELECT * FROM blog WHERE blogID='$_SESSION[blogID]'";
		$result=$db_handle->fetchRecord($sql);
		require_once 'web/BlogFormEditAdmin.php';
		break;
		
	case "updateForAdmin":
		if(isset($_POST['title']))
		{
			$title=$_POST['title'];
			$title=filter_var($title, FILTER_SANITIZE_STRING);
		}
		
		if(isset($_POST['shortDesc']))
		{
			$shortDesc=$_POST['shortDesc'];
			$shortDesc=filter_var($shortDesc, FILTER_SANITIZE_STRING);
		}
		
		if(isset($_POST['publishedDate']))
		{
			$publishedDate=$_POST['publishedDate'];
			$publishedDate=filter_var($publishedDate, FILTER_SANITIZE_STRING);
		}
		
		if(isset($_POST['author']))
		{
			$author=$_POST['author'];
			$author=filter_var($author, FILTER_SANITIZE_STRING);
		}
		
		if(isset($_GET['blogID']))
		{
			$blogID=$_GET['blogID'];
		}
		
		$image = $_FILES['image']['name'];
		$target = "images/".basename($image);
		$temp=$_FILES['image']['tmp_name'];
		$sql="UPDATE blog SET title='$title',shortDesc='$shortDesc',publishedDate='$publishedDate',author='$author',image='$image' WHERE blogID='$blogID'";
		$result=$db_handle->insertBlogDetails($sql,$temp,$target);
		if($result)
		{
			require_once 'web/showBlogs.php';
		}
		
		else
		{
			echo 'Cant edit';
			require_once 'web/error.php';
		}
		break;
		
	case "update":
		if(isset($_POST['title']))
		{
			$title=$_POST['title'];
			$title=filter_var($title, FILTER_SANITIZE_STRING);
		}
		
		if(isset($_POST['shortDesc']))
		{
			$shortDesc=$_POST['shortDesc'];
			$shortDesc=filter_var($shortDesc, FILTER_SANITIZE_STRING);
		}
		
		if(isset($_POST['publishedDate']))
		{
			$publishedDate=$_POST['publishedDate'];
			$publishedDate=filter_var($publishedDate, FILTER_SANITIZE_STRING);
		}
		
		if(isset($_POST['author']))
		{
			$author=$_POST['author'];
			$author=filter_var($author, FILTER_SANITIZE_STRING);
		}
		
		$blogID=$_SESSION['blogId'];
		$image = $_FILES['image']['name'];
		$target = "images/".basename($image);
		$temp=$_FILES['image']['tmp_name'];
		$sql="UPDATE blog SET title='$title',shortDesc='$shortDesc',publishedDate='$publishedDate',author='$author',image='$image' WHERE blogId='$blogID'";
		$result=$db_handle->insertBlogDetails($sql,$temp,$target);
		if($result)
		{
			require_once 'web/createBlog.php';
		}
		
		else
		{
			echo 'Cant edit';
			require_once 'web/error.php';
		}
		break;

    case "delete":
        $blogId=$_GET['blogId'];
		$sql="DELETE FROM blog WHERE blogId='$blogId'";
        $result=$db_handle->deleteRecord($sql);

        if($result==true)
        {
                require_once 'web/createBlog.php';
        }
        
        else
        {
            echo "Failed to delete the record from the table " . mysqli_error($db_handle);
             require_once 'web/error.php';
        }
        break; 

    case "logout":
        require_once 'web/logout.php';
        break;

    case "deleteForAdmin":
        $blogID=$_GET['blogID'];
		$sql="DELETE FROM blog WHERE blogID='$blogID'";
        $result=$db_handle->deleteRecord($sql);
        require_once 'web/showBlogs.php';
        break; 

    case "UsersBlog":
        //$sql="SELECT * from blog order by author";
        //$result=$db_handle->fetchRecord($sql);
        require_once 'web/UsersBlog.php';
    
		
	case "showBlogs":
		require_once 'web/showBlogs.php';
		break;
		
	case "createBlog":
		require_once "web/BlogForm.php";
		break;
		
	case "pagination":
		$page=$_GET['page'];
		require_once "web/Blogs.php";
		break;
		
	case "paginationByAdmin":
		$page=$_GET['page'];
		require_once "web/UsersBlog.php";
		break;
		
	case "ListUser":
		$sql="SELECT * FROM user where user_type='user'";
		$result=$db_handle->fetchRecord($sql);
		require_once "web/ListUser.php";
		break;
		
	case "deleteUser":
		$id=$_GET['id'];
		$sql="DELETE FROM user WHERE id='$id'";
		$sql1="DELETE FROM blog where id='$id'";
		$result=$db_handle->deleteRecord($sql);
		$result1=$db_handle->deleteRecord($sql1);
		
		if($result || $result1)
		{
			require_once "web/showBlogs.php";
		}
		
		else
		{
			echo "Error in deleting the user" . mysqli_error($db_handle);
            require_once 'web/error.php';
		}
		break;
		
    default:
        require_once "web/choose.php";
        break;
}
?>
