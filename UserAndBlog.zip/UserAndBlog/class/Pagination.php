<?php
	require_once ("class/DBController.php");
	class Pagination
	{
		private $db_handle;
    
		function __construct()
		{
			$this->db_handle = new DBController();
		}
		
		function paginate($results_per_page)
		{
			$number_of_pages = $this->noOfPages($results_per_page);
			if (!isset($_GET['page']))
			{
				$page = 1;
			}

			else
			{
				$page = $_GET['page'];
			}
		
			$this_page_first_result = ($page-1)*$results_per_page;
			return $this_page_first_result;
		}
		
		function select($this_page_first_result,$results_per_page)
		{
			$sql="SELECT * FROM blog WHERE id='$_SESSION[user_id]' LIMIT " . $this_page_first_result . "," .  $results_per_page;
			$result = $this->db_handle->pagination($sql);
			return $result;
		}
		
		function noOfPages($results_per_page)
		{
			$sql="SELECT * FROM blog WHERE id='$_SESSION[user_id]'";
			$result=$this->db_handle->pagination($sql);
			$number_of_results = mysqli_num_rows($result);
			$number_of_pages = ceil($number_of_results/$results_per_page);
			return $number_of_pages;
		}
		
		function paginateAdmin($results_per_page)
		{
			$number_of_pages = $this->noOfPagesAdmin($results_per_page);
			if (!isset($_GET['page']))
			{
				$page = 1;
			}

			else
			{
				$page = $_GET['page'];
			}
		
			$this_page_first_result = ($page-1)*$results_per_page;
			return $this_page_first_result;
		}
		
		function selectAdmin($this_page_first_result,$results_per_page)
		{
			$sql="SELECT * FROM blog order by author LIMIT " . $this_page_first_result . "," .  $results_per_page;
			$result = $this->db_handle->pagination($sql);
			return $result;
		}
		
		function noOfPagesAdmin($results_per_page)
		{
			$sql="SELECT * FROM blog order by author";
			$result=$this->db_handle->pagination($sql);
			$number_of_results = mysqli_num_rows($result);
			$number_of_pages = ceil($number_of_results/$results_per_page);
			return $number_of_pages;
		}
	}	
?>