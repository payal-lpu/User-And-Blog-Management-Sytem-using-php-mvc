<?php
session_start();
class DBController {
    private $host = "localhost";
    private $user = "root";
    private $password = "";
    private $database = "userandblog";
    private $conn;
    
    public function __construct() {
        $this->conn = $this->connectDB();
    }   
    
    public function connectDB() {
        $conn = mysqli_connect($this->host,$this->user,$this->password,$this->database);
        return $conn;
    }
    
    public function insert($sql)
    {
        if(mysqli_query($this->conn,$sql))
	    {
		    return true;
	    }
	
	    else
	    {
		    return false;
	    }
    }
	
	public function insertBlogDetails($sql,$temp,$target)
	{
		mysqli_query($this->conn, $sql);

		if (move_uploaded_file($temp, $target))
		{
			$msg = "Image uploaded successfully";
			return true;
		}
		else
		{
			$msg = "Failed to upload image";
			return false;
		}
	}

    public function select($sql,$user)
    {
        $data = mysqli_query($this->conn,$sql);
               
	    $total= mysqli_num_rows($data);

        $result=mysqli_fetch_assoc($data);
	    if($total==1)
	    {
            return $result;
	    }
	
        else
	    {
            return "";
	    }
    }

    public function fetchRecord($sql)
    {
        $result = mysqli_query($this->conn,$sql);   
        if(mysqli_num_rows($result)>0)
        {
            while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
            {
                $resultset[]=$row;
            }
        }

        else
        {
            $resultset=array();
        }
       
           return $resultset;
       
    }

    public function deleteRecord($sql)
    {
        $result=mysqli_query($this->conn,$sql);
        if($result)
        {
            return true;
        }

        else
        {
            return false;
        }
    }
	
	public function update($sql)
    {
        $result=mysqli_query($this->conn,$sql);
        if($result)
        {
            return true;
        }

        else
        {
            return false;
        }
    }
	
	public function countRecord($sql)
    {
        $result = mysqli_query($this->conn,$sql);   
        if(mysqli_num_rows($result)>0)
        {
            while($row=mysqli_fetch_array($result,MYSQLI_ASSOC))
            {
               return true;
            }
        }

        else
        {
            return false;
        }      
    }
	
	public function pagination($sql)
	{
		$result=mysqli_query($this->conn,$sql);
		return $result;
	}
}
?>